"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const scramjet_1 = require("scramjet");
const mod = function (_input) {
    this.logger.info("Sequence started");
    return scramjet_1.DataStream.from(_input)
        .map((chunk) => {
        return `Hello ${chunk}!`;
    })
        .do(console.log);
};
exports.default = mod;
//# sourceMappingURL=index.js.map