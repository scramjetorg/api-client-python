import { ReadableApp } from "@scramjet/types";
declare const mod: ReadableApp;
export default mod;
